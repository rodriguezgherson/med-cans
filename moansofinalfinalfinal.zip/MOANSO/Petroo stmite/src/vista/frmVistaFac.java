package vista;
import dao.MascotaDAOx;
import dao.daoProducto;
import datos.factura;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
public final class frmVistaFac extends javax.swing.JFrame {
DefaultTableModel dtmVista = new DefaultTableModel();
MascotaDAOx DaoF=new MascotaDAOx("Factura.txt");

    
    public frmVistaFac() {
                initComponents();

               setLocationRelativeTo(this);

        llenaColumna();
        listar();
       //  Date jeje = new Date();
        //SimpleDateFormat formateador = new SimpleDateFormat("dd-MM-yyyy");
        //lblFecha.setText("" + formateador.format(jeje));
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        btnAnular = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tvista = new javax.swing.JTable();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnAnular.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Anular.png"))); // NOI18N
        btnAnular.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnAnular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnularActionPerformed(evt);
            }
        });
        jPanel2.add(btnAnular, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 30, 110, 40));

        jLabel1.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        jLabel1.setText("FACTURAS GUARDADAS");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        jButton1.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Salir_1.png"))); // NOI18N
        jButton1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 30, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 120));

        jPanel3.setBackground(new java.awt.Color(36, 47, 65));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tvista.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        tvista.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tvista.setGridColor(new java.awt.Color(0, 0, 153));
        tvista.setRowHeight(20);
        tvista.setSelectionBackground(new java.awt.Color(204, 204, 204));
        tvista.setShowVerticalLines(false);
        jScrollPane1.setViewportView(tvista);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 900, 310));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 920, 350));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAnularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnularActionPerformed
int msg = JOptionPane.showConfirmDialog(this,"Deseas Modificar el Registro","Modificar",JOptionPane.YES_NO_OPTION);
       if(msg == JOptionPane.YES_OPTION){
           
                   int fil= tvista.getSelectedRow();

                  String numero =tvista.getValueAt(fil,1).toString();

          factura a = DaoF.buscarfactura(numero);
          if(a != null){
              //modificar datos
              a.setEstado("ANULADO");
              
              
              listar();//actualizar la lista
              DaoF.grabar();//Grabar datos al archivo
              JOptionPane.showMessageDialog(this,"Registro Actualizado!!!","Mensaje",1);
          }

       }        // TODO add your handling code here:
    }//GEN-LAST:event_btnAnularActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        Menu ad = new Menu();
        
        ad.setVisible(true);
        this.setVisible(false);
        
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmVistaFac.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmVistaFac.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmVistaFac.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmVistaFac.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmVistaFac().setVisible(true);
            }
        });
    }
   public void listar(){
    if (DaoF.tamaño() == 0) {
            JOptionPane.showMessageDialog(this, "Archivo cliente sin registro!", "Validación", 1);
        } else {
            dtmVista.setRowCount(0);
            for (int i = 0; i < DaoF.tamaño(); i++) {
                Object vec[] = new Object[15];
                vec[0] = DaoF.obtener(i).getSerie();
                vec[1] = DaoF.obtener(i).getNumero();
                vec[2] = DaoF.obtener(i).getDireccion();
                vec[3] = DaoF.obtener(i).getRazon();
                vec[4] = DaoF.obtener(i).getRuc();
                vec[5] = DaoF.obtener(i).getEstado();
                vec[6] = DaoF.obtener(i).getCantidad();
                vec[7] = DaoF.obtener(i).getCodigo();
                vec[8] = DaoF.obtener(i).getDescripcion();
                vec[9] = DaoF.obtener(i).getPrecio();
                vec[10] = DaoF.obtener(i).getFecha();
                vec[11] = DaoF.obtener(i).getHora();
                vec[12] = DaoF.obtener(i).getSubTotal();
                vec[13] = DaoF.obtener(i).getIGV();
                vec[14] = DaoF.obtener(i).getTotal();
               


                dtmVista.addRow(vec);
            }

            tvista.setModel(dtmVista);
        }
    }
    public void llenaColumna() {
        dtmVista.addColumn("Serie");
        dtmVista.addColumn("numero");
        dtmVista.addColumn("Direccion");
        dtmVista.addColumn("Razon");
        dtmVista.addColumn("Ruc");
        dtmVista.addColumn("Estado");
        dtmVista.addColumn("Cantidad");
        dtmVista.addColumn("Codigo");
        dtmVista.addColumn("Descripcion");
        dtmVista.addColumn("Precio");
        dtmVista.addColumn("Fecha");
        dtmVista.addColumn("Hora");
        dtmVista.addColumn("SubTotal");
        dtmVista.addColumn("IGV");
        dtmVista.addColumn("Total");        
        tvista.setModel(dtmVista);
    
    }
 
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnular;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tvista;
    // End of variables declaration//GEN-END:variables

   
}


