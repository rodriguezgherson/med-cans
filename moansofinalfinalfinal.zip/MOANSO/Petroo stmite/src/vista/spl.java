/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

/**
 *
 * @author misae
 */
public class spl {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        SplashScreen splash = new SplashScreen();
        splash.setVisible(true);
        Home ho = new Home();
        try {
            for(int i=0; i<101; i++){
            Thread.sleep(40);
            splash.progressBar.setValue(i);
                
                if(i==100){
                ho.setVisible(true);
                splash.setVisible(false);
                }
            }
        }
        catch(Exception e) {
        }
    }
    
}
