
package vista;

import javax.swing.JOptionPane;

public class Menu extends javax.swing.JFrame {

    public Menu() {
        initComponents();
        setLocationRelativeTo(this);
        butProducto.setVisible(false);
        butCliente.setVisible(false);
        butMascota.setVisible(false);
        butFacturas.setVisible(false);
        butVentas.setVisible(false);
        butVerFacturas.setVisible(false);
        butAtenciones.setVisible(false);
        downOne.setVisible(false);
        downTwo.setVisible(false);
        downThree.setVisible(false);
        downFive.setVisible(false);
        downFour.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        O_Producto = new javax.swing.JPanel();
        PRODU = new javax.swing.JLabel();
        O_Cliente_Mascota = new javax.swing.JPanel();
        CLIE_MASC = new javax.swing.JLabel();
        O_Atenciones = new javax.swing.JPanel();
        ATENCION = new javax.swing.JLabel();
        Consultas1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        Consultas2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        Consultas3 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        User = new javax.swing.JLabel();
        O_Ventas = new javax.swing.JPanel();
        VENTA = new javax.swing.JLabel();
        Consultas5 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        Consultas6 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        Consultas7 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        Consultas8 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        Consultas9 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        Consultas10 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        Consultas11 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        O_Ver_Facturas = new javax.swing.JPanel();
        VER_FACT = new javax.swing.JLabel();
        Consultas13 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        Consultas14 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        Consultas15 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        butSalir = new javax.swing.JLabel();
        butCliente = new javax.swing.JLabel();
        butProducto = new javax.swing.JLabel();
        butMascota = new javax.swing.JLabel();
        butAtenciones = new javax.swing.JLabel();
        downOne = new javax.swing.JLabel();
        upOne = new javax.swing.JLabel();
        downTwo = new javax.swing.JLabel();
        upTwo = new javax.swing.JLabel();
        downFive = new javax.swing.JLabel();
        upFive = new javax.swing.JLabel();
        upThree = new javax.swing.JLabel();
        downThree = new javax.swing.JLabel();
        downFour = new javax.swing.JLabel();
        upFour = new javax.swing.JLabel();
        butVerFacturas = new javax.swing.JLabel();
        butVentas = new javax.swing.JLabel();
        butFacturas = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(36, 47, 65));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Rockwell Condensed", 0, 55)); // NOI18N
        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Bienvenido");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Segoe Print", 0, 25)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Escoja una opcion");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 50, -1, -1));

        jLabel1.setFont(new java.awt.Font("Rockwell Condensed", 1, 28)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("MediCans Software");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 0, 270, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 910, 110));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        O_Producto.setBackground(new java.awt.Color(36, 47, 65));
        O_Producto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                O_ProductoMouseClicked(evt);
            }
        });
        O_Producto.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PRODU.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/IMAGEN0001.PNG"))); // NOI18N
        PRODU.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                PRODUMouseMoved(evt);
            }
        });
        PRODU.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PRODUMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PRODUMouseExited(evt);
            }
        });
        O_Producto.add(PRODU, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, -10, 190, -1));

        jPanel2.add(O_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 130, 170));

        O_Cliente_Mascota.setBackground(new java.awt.Color(36, 47, 65));
        O_Cliente_Mascota.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        CLIE_MASC.setForeground(java.awt.Color.white);
        CLIE_MASC.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/IMAGEN0002.PNG"))); // NOI18N
        CLIE_MASC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CLIE_MASCMouseClicked(evt);
            }
        });
        O_Cliente_Mascota.add(CLIE_MASC, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, -20, 200, 210));

        jPanel2.add(O_Cliente_Mascota, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, 140, 170));

        O_Atenciones.setBackground(new java.awt.Color(36, 47, 65));
        O_Atenciones.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ATENCION.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/ATENC.PNG"))); // NOI18N
        ATENCION.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ATENCIONMouseClicked(evt);
            }
        });
        O_Atenciones.add(ATENCION, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 180));

        Consultas1.setBackground(new java.awt.Color(36, 47, 65));
        Consultas1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Ask Question-64.png"))); // NOI18N
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        Consultas1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 60, -1));

        O_Atenciones.add(Consultas1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 140, 160));

        Consultas2.setBackground(new java.awt.Color(36, 47, 65));
        Consultas2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Ask Question-64.png"))); // NOI18N
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        Consultas2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 60, -1));

        Consultas3.setBackground(new java.awt.Color(36, 47, 65));
        Consultas3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Ask Question-64.png"))); // NOI18N
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });
        Consultas3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 60, -1));

        Consultas2.add(Consultas3, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 140, 160));

        O_Atenciones.add(Consultas2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 140, 160));

        jPanel2.add(O_Atenciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 10, 140, 170));

        jPanel13.setBackground(new java.awt.Color(67, 87, 121));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        User.setFont(new java.awt.Font("Segoe UI Emoji", 0, 48)); // NOI18N
        User.setForeground(java.awt.Color.white);
        User.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Add User Male-64.png"))); // NOI18N
        User.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UserMouseClicked(evt);
            }
        });
        jPanel13.add(User, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jPanel2.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 50, 100, 100));

        O_Ventas.setBackground(new java.awt.Color(36, 47, 65));
        O_Ventas.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        VENTA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/IMAGEN0003.PNG"))); // NOI18N
        VENTA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VENTAMouseClicked(evt);
            }
        });
        O_Ventas.add(VENTA, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 0, 170, 170));

        Consultas5.setBackground(new java.awt.Color(36, 47, 65));
        Consultas5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Ask Question-64.png"))); // NOI18N
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });
        Consultas5.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 60, -1));

        O_Ventas.add(Consultas5, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 140, 160));

        Consultas6.setBackground(new java.awt.Color(36, 47, 65));
        Consultas6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Ask Question-64.png"))); // NOI18N
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });
        Consultas6.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 60, -1));

        Consultas7.setBackground(new java.awt.Color(36, 47, 65));
        Consultas7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Ask Question-64.png"))); // NOI18N
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });
        Consultas7.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 60, -1));

        Consultas6.add(Consultas7, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 140, 160));

        O_Ventas.add(Consultas6, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 140, 160));

        Consultas8.setBackground(new java.awt.Color(36, 47, 65));
        Consultas8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Ask Question-64.png"))); // NOI18N
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });
        Consultas8.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 60, -1));

        Consultas9.setBackground(new java.awt.Color(36, 47, 65));
        Consultas9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Ask Question-64.png"))); // NOI18N
        jLabel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel15MouseClicked(evt);
            }
        });
        Consultas9.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 60, -1));

        Consultas8.add(Consultas9, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 140, 160));

        Consultas10.setBackground(new java.awt.Color(36, 47, 65));
        Consultas10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Ask Question-64.png"))); // NOI18N
        jLabel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel16MouseClicked(evt);
            }
        });
        Consultas10.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 60, -1));

        Consultas11.setBackground(new java.awt.Color(36, 47, 65));
        Consultas11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Ask Question-64.png"))); // NOI18N
        jLabel17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel17MouseClicked(evt);
            }
        });
        Consultas11.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 60, -1));

        Consultas10.add(Consultas11, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 140, 160));

        Consultas8.add(Consultas10, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 140, 160));

        O_Ventas.add(Consultas8, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 20, 140, 160));

        jPanel2.add(O_Ventas, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 10, 140, 170));

        O_Ver_Facturas.setBackground(new java.awt.Color(0, 0, 0));
        O_Ver_Facturas.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        VER_FACT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/FACT.PNG"))); // NOI18N
        VER_FACT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VER_FACTMouseClicked(evt);
            }
        });
        O_Ver_Facturas.add(VER_FACT, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, -70, 160, 310));

        Consultas13.setBackground(new java.awt.Color(36, 47, 65));
        Consultas13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Ask Question-64.png"))); // NOI18N
        jLabel19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel19MouseClicked(evt);
            }
        });
        Consultas13.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 60, -1));

        O_Ver_Facturas.add(Consultas13, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 140, 160));

        Consultas14.setBackground(new java.awt.Color(36, 47, 65));
        Consultas14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Ask Question-64.png"))); // NOI18N
        jLabel20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel20MouseClicked(evt);
            }
        });
        Consultas14.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 60, -1));

        Consultas15.setBackground(new java.awt.Color(36, 47, 65));
        Consultas15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Ask Question-64.png"))); // NOI18N
        jLabel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel21MouseClicked(evt);
            }
        });
        Consultas15.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 60, -1));

        Consultas14.add(Consultas15, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 140, 160));

        O_Ver_Facturas.add(Consultas14, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 140, 160));

        jPanel2.add(O_Ver_Facturas, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 10, 140, 170));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 910, 190));

        jPanel3.setBackground(new java.awt.Color(36, 47, 65));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(61, 69, 86));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 290, 660, 100));

        jPanel5.setBackground(new java.awt.Color(61, 69, 86));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(61, 69, 86));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel5.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 290, 660, 100));

        jPanel3.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 290, 660, 100));

        butSalir.setFont(new java.awt.Font("Rockwell Condensed", 1, 28)); // NOI18N
        butSalir.setForeground(new java.awt.Color(255, 255, 255));
        butSalir.setText("Salir");
        butSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                butSalirMouseClicked(evt);
            }
        });
        jPanel3.add(butSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 100, -1, -1));

        butCliente.setFont(new java.awt.Font("Segoe Print", 0, 18)); // NOI18N
        butCliente.setForeground(java.awt.Color.white);
        butCliente.setText("- Cliente");
        butCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                butClienteMouseClicked(evt);
            }
        });
        jPanel3.add(butCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 60, -1, -1));

        butProducto.setFont(new java.awt.Font("Segoe Print", 0, 18)); // NOI18N
        butProducto.setForeground(java.awt.Color.white);
        butProducto.setText("- Producto");
        butProducto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                butProductoMouseClicked(evt);
            }
        });
        jPanel3.add(butProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));

        butMascota.setFont(new java.awt.Font("Segoe Print", 0, 18)); // NOI18N
        butMascota.setForeground(java.awt.Color.white);
        butMascota.setText("- Mascota");
        butMascota.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                butMascotaMouseClicked(evt);
            }
        });
        jPanel3.add(butMascota, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, -1, -1));

        butAtenciones.setBackground(new java.awt.Color(255, 153, 102));
        butAtenciones.setFont(new java.awt.Font("Segoe Print", 0, 18)); // NOI18N
        butAtenciones.setForeground(java.awt.Color.white);
        butAtenciones.setText("- Atenciones");
        butAtenciones.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                butAtencionesMouseClicked(evt);
            }
        });
        jPanel3.add(butAtenciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 60, -1, -1));

        downOne.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Chevron Down-64.png"))); // NOI18N
        downOne.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                downOneMouseClicked(evt);
            }
        });
        jPanel3.add(downOne, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, -1, -1));

        upOne.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Chevron Up-64.png"))); // NOI18N
        upOne.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                upOneMouseClicked(evt);
            }
        });
        jPanel3.add(upOne, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, -10, -1, -1));

        downTwo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Chevron Down-64.png"))); // NOI18N
        downTwo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                downTwoMouseClicked(evt);
            }
        });
        jPanel3.add(downTwo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, -1, -1));

        upTwo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Chevron Up-64.png"))); // NOI18N
        upTwo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                upTwoMouseClicked(evt);
            }
        });
        jPanel3.add(upTwo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, -10, -1, -1));

        downFive.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Chevron Down-64.png"))); // NOI18N
        downFive.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                downFiveMouseClicked(evt);
            }
        });
        jPanel3.add(downFive, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 10, -1, -1));

        upFive.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Chevron Up-64.png"))); // NOI18N
        upFive.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                upFiveMouseClicked(evt);
            }
        });
        jPanel3.add(upFive, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, -10, -1, -1));

        upThree.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Chevron Up-64.png"))); // NOI18N
        upThree.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                upThreeMouseClicked(evt);
            }
        });
        jPanel3.add(upThree, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, -10, -1, -1));

        downThree.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Chevron Down-64.png"))); // NOI18N
        downThree.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                downThreeMouseClicked(evt);
            }
        });
        jPanel3.add(downThree, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 10, -1, -1));

        downFour.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Chevron Down-64.png"))); // NOI18N
        downFour.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                downFourMouseClicked(evt);
            }
        });
        jPanel3.add(downFour, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 10, -1, -1));

        upFour.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icons8-Chevron Up-64.png"))); // NOI18N
        upFour.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                upFourMouseClicked(evt);
            }
        });
        jPanel3.add(upFour, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, -10, -1, -1));

        butVerFacturas.setFont(new java.awt.Font("Segoe Print", 0, 18)); // NOI18N
        butVerFacturas.setForeground(java.awt.Color.white);
        butVerFacturas.setText("- Ver Facturas");
        butVerFacturas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                butVerFacturasMouseClicked(evt);
            }
        });
        jPanel3.add(butVerFacturas, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 80, -1, -1));

        butVentas.setFont(new java.awt.Font("Segoe Print", 0, 18)); // NOI18N
        butVentas.setForeground(java.awt.Color.white);
        butVentas.setText("- Ventas");
        butVentas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                butVentasMouseClicked(evt);
            }
        });
        jPanel3.add(butVentas, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 60, -1, -1));

        butFacturas.setFont(new java.awt.Font("Segoe Print", 0, 18)); // NOI18N
        butFacturas.setForeground(java.awt.Color.white);
        butFacturas.setText("- Facturas");
        butFacturas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                butFacturasMouseClicked(evt);
            }
        });
        jPanel3.add(butFacturas, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 60, -1, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 910, 140));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void butClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_butClienteMouseClicked
     // TODO add your handling code here:
     try{
        frmCliente Xcliente = new frmCliente();
        Xcliente.setVisible(true);
        this.setVisible(false);
       }catch(Exception e){}
              
    }//GEN-LAST:event_butClienteMouseClicked

    private void butProductoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_butProductoMouseClicked
    try{
        frmProducto XfrmProducto = new frmProducto();
        XfrmProducto.setVisible(true);
        this.setVisible(false);
       }catch(Exception e){}        // TODO add your handling code here:
    }//GEN-LAST:event_butProductoMouseClicked

    private void butMascotaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_butMascotaMouseClicked
    try{
        frmMascota XMascota = new frmMascota();
        XMascota.setVisible(true);
        this.setVisible(false);
       }catch(Exception e){}
             // TODO add your handling code here:
    }//GEN-LAST:event_butMascotaMouseClicked

    private void butSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_butSalirMouseClicked
 Home acs=new Home();
         acs.setVisible(true);
         this.setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_butSalirMouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        butProducto.setVisible(false);
        
        butCliente.setVisible(false);
        butMascota.setVisible(false);
       
        butAtenciones.setVisible(false);
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel2MouseClicked

    private void downOneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_downOneMouseClicked
        butProducto.setVisible(false);
        downOne.setVisible(false);
        upOne.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_downOneMouseClicked

    private void upOneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_upOneMouseClicked
        butProducto.setVisible(true);
        upOne.setVisible(false);
        downOne.setVisible(true)
        ;// TODO add your handling code here:
    }//GEN-LAST:event_upOneMouseClicked

    private void downTwoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_downTwoMouseClicked
        butCliente.setVisible(false);
        butMascota.setVisible(false); 
        upTwo.setVisible(true);
        downTwo.setVisible(false);
       // TODO add your handling code here:
    }//GEN-LAST:event_downTwoMouseClicked

    private void upTwoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_upTwoMouseClicked
        butCliente.setVisible(true);
        butMascota.setVisible(true); 
        upTwo.setVisible(false);
        downTwo.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_upTwoMouseClicked

    private void upFiveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_upFiveMouseClicked
        
        butVerFacturas.setVisible(true);
        butFacturas.setVisible(true);
        upFive.setVisible(false);
        downFive.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_upFiveMouseClicked

    private void downFiveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_downFiveMouseClicked
        butVerFacturas.setVisible(false);
        butFacturas.setVisible(false);
        upFive.setVisible(true);
        downFive.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_downFiveMouseClicked

    private void ATENCIONMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ATENCIONMouseClicked
            butAtenciones.setVisible(true);
            upThree.setVisible(false);
            downThree.setVisible(true); // TODO add your handling code here:
    }//GEN-LAST:event_ATENCIONMouseClicked

    private void UserMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UserMouseClicked
        Account user = new Account();    
        user.setVisible(true);
        this.setVisible(false);
            // TODO add your handling code here:
    }//GEN-LAST:event_UserMouseClicked

    private void butAtencionesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_butAtencionesMouseClicked
       try{
        frmAtenciones XAtenciones = new frmAtenciones();
        XAtenciones.setVisible(true);
        this.setVisible(false);
       }catch(Exception e){}
    }//GEN-LAST:event_butAtencionesMouseClicked

    private void O_ProductoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_O_ProductoMouseClicked

        // TODO add your handling code here:
    }//GEN-LAST:event_O_ProductoMouseClicked

    private void PRODUMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PRODUMouseExited

        // TODO add your handling code here:
    }//GEN-LAST:event_PRODUMouseExited

    private void PRODUMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PRODUMouseClicked

        butProducto.setVisible(true);
        upOne.setVisible(false);
        downOne.setVisible(true);
    }//GEN-LAST:event_PRODUMouseClicked

    private void PRODUMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PRODUMouseMoved

        // TODO add your handling code here:
    }//GEN-LAST:event_PRODUMouseMoved

    private void CLIE_MASCMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CLIE_MASCMouseClicked
        butMascota.setVisible(true);
        butCliente.setVisible(true);
        upTwo.setVisible(false);
        downTwo.setVisible(true); // TODO add your handling code here:
    }//GEN-LAST:event_CLIE_MASCMouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel9MouseClicked

    private void VENTAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VENTAMouseClicked
        butVentas.setVisible(true);
        upFour.setVisible(false);
        downFour.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_VENTAMouseClicked

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel12MouseClicked

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel13MouseClicked

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel14MouseClicked

    private void jLabel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel15MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel15MouseClicked

    private void jLabel16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel16MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel16MouseClicked

    private void jLabel17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel17MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel17MouseClicked

    private void VER_FACTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VER_FACTMouseClicked
         butVerFacturas.setVisible(true);
         butFacturas.setVisible(true);
            upFive.setVisible(false);
            downFive.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_VER_FACTMouseClicked

    private void jLabel19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel19MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel19MouseClicked

    private void jLabel20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel20MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel20MouseClicked

    private void jLabel21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel21MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel21MouseClicked

    private void upThreeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_upThreeMouseClicked
        butAtenciones.setVisible(true);
        upThree.setVisible(false);
        downThree.setVisible(true); // TODO add your handling code here:
    }//GEN-LAST:event_upThreeMouseClicked

    private void downThreeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_downThreeMouseClicked
        butAtenciones.setVisible(false);
        upThree.setVisible(true);
        downThree.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_downThreeMouseClicked

    private void downFourMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_downFourMouseClicked
       butVentas.setVisible(false);
        upFour.setVisible(true);
        downFour.setVisible(false); // TODO add your handling code here:
    }//GEN-LAST:event_downFourMouseClicked

    private void upFourMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_upFourMouseClicked
        butVentas.setVisible(true);
        upFour.setVisible(false);
        downFour.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_upFourMouseClicked

    private void butVerFacturasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_butVerFacturasMouseClicked
        try{
        frmVistaFac XVistaFac = new frmVistaFac();
        XVistaFac.setVisible(true);
        this.setVisible(false);
       }catch(Exception e){}// TODO add your handling code here:
    }//GEN-LAST:event_butVerFacturasMouseClicked

    private void butVentasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_butVentasMouseClicked
        try{
        frmVentasProducto XVentas = new frmVentasProducto();
        XVentas.setVisible(true);
        this.setVisible(false);
       }catch(Exception e){}// TODO add your handling code here:
    }//GEN-LAST:event_butVentasMouseClicked

    private void butFacturasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_butFacturasMouseClicked
        try{
        frmFactura XFacturas = new frmFactura();
        XFacturas.setVisible(true);
        this.setVisible(false);
       }catch(Exception e){}// TODO add your handling code here:
    }//GEN-LAST:event_butFacturasMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                new Menu().setVisible(true);
             
            }   
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ATENCION;
    private javax.swing.JLabel CLIE_MASC;
    private javax.swing.JPanel Consultas1;
    private javax.swing.JPanel Consultas10;
    private javax.swing.JPanel Consultas11;
    private javax.swing.JPanel Consultas13;
    private javax.swing.JPanel Consultas14;
    private javax.swing.JPanel Consultas15;
    private javax.swing.JPanel Consultas2;
    private javax.swing.JPanel Consultas3;
    private javax.swing.JPanel Consultas5;
    private javax.swing.JPanel Consultas6;
    private javax.swing.JPanel Consultas7;
    private javax.swing.JPanel Consultas8;
    private javax.swing.JPanel Consultas9;
    private javax.swing.JPanel O_Atenciones;
    private javax.swing.JPanel O_Cliente_Mascota;
    private javax.swing.JPanel O_Producto;
    private javax.swing.JPanel O_Ventas;
    private javax.swing.JPanel O_Ver_Facturas;
    private javax.swing.JLabel PRODU;
    private javax.swing.JLabel User;
    private javax.swing.JLabel VENTA;
    private javax.swing.JLabel VER_FACT;
    private javax.swing.JLabel butAtenciones;
    private javax.swing.JLabel butCliente;
    private javax.swing.JLabel butFacturas;
    private javax.swing.JLabel butMascota;
    private javax.swing.JLabel butProducto;
    private javax.swing.JLabel butSalir;
    private javax.swing.JLabel butVentas;
    private javax.swing.JLabel butVerFacturas;
    private javax.swing.JLabel downFive;
    private javax.swing.JLabel downFour;
    private javax.swing.JLabel downOne;
    private javax.swing.JLabel downThree;
    private javax.swing.JLabel downTwo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JLabel upFive;
    private javax.swing.JLabel upFour;
    private javax.swing.JLabel upOne;
    private javax.swing.JLabel upThree;
    private javax.swing.JLabel upTwo;
    // End of variables declaration//GEN-END:variables
}
