
package vista;
import datos.Mascota;
import dao.DuenhoDAO;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class frmCliente extends javax.swing.JFrame {

    DefaultTableModel modelo;

    public frmCliente() {
        initComponents();
        modelo = new DefaultTableModel();
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido Paterno");
        modelo.addColumn("Apellido Materno");
        modelo.addColumn("Mascota");
        modelo.addColumn("Celular");
        modelo.addColumn("Direccion");
        this.tblCliente.setModel(modelo); 
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jCelular = new javax.swing.JLabel();
        txtCELULAR = new javax.swing.JTextField();
        jApellidoMaterno = new javax.swing.JLabel();
        txtAPEMAT = new javax.swing.JTextField();
        jDireccion = new javax.swing.JLabel();
        txtDIRECCION = new javax.swing.JTextField();
        btnNuevo = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnGrabar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        txtNOMBRE = new javax.swing.JTextField();
        txtAPEPAT = new javax.swing.JTextField();
        jNombre1 = new javax.swing.JLabel();
        jApellidoPaterno = new javax.swing.JLabel();
        jNombre2 = new javax.swing.JLabel();
        txtNOMBRE1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblCliente = new javax.swing.JTable();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 590, -1));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Segoe UI Emoji", 1, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("REGISTRO DE CLIENTES");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 360, -1));

        jPanel4.setBackground(new java.awt.Color(36, 47, 65));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jCelular.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jCelular.setForeground(new java.awt.Color(255, 255, 255));
        jCelular.setText("Celular");
        jPanel4.add(jCelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 90, -1, -1));

        txtCELULAR.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCELULARKeyTyped(evt);
            }
        });
        jPanel4.add(txtCELULAR, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 90, 120, -1));

        jApellidoMaterno.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jApellidoMaterno.setForeground(new java.awt.Color(255, 255, 255));
        jApellidoMaterno.setText("Apellido Materno");
        jPanel4.add(jApellidoMaterno, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 120, -1, 20));

        txtAPEMAT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAPEMATActionPerformed(evt);
            }
        });
        txtAPEMAT.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtAPEMATKeyTyped(evt);
            }
        });
        jPanel4.add(txtAPEMAT, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 120, 173, -1));

        jDireccion.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jDireccion.setForeground(new java.awt.Color(255, 255, 255));
        jDireccion.setText("Direccion");
        jPanel4.add(jDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 120, -1, -1));

        txtDIRECCION.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDIRECCIONKeyTyped(evt);
            }
        });
        jPanel4.add(txtDIRECCION, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 120, 240, -1));

        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Nuevo_1.png"))); // NOI18N
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        jPanel4.add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 10, 100, 20));

        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Buscar_1.png"))); // NOI18N
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        jPanel4.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, 90, 20));

        btnGrabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Grabar_1.png"))); // NOI18N
        btnGrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabarActionPerformed(evt);
            }
        });
        jPanel4.add(btnGrabar, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 180, 80, 20));

        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Actualizar_1.png"))); // NOI18N
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        jPanel4.add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 10, 100, 20));

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Eliminar_2.png"))); // NOI18N
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel4.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 180, 90, 20));

        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Salir_2.png"))); // NOI18N
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        jPanel4.add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 10, 78, 20));

        txtNOMBRE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNOMBREActionPerformed(evt);
            }
        });
        txtNOMBRE.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNOMBREKeyTyped(evt);
            }
        });
        jPanel4.add(txtNOMBRE, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 150, 173, -1));

        txtAPEPAT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAPEPATActionPerformed(evt);
            }
        });
        txtAPEPAT.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtAPEPATKeyTyped(evt);
            }
        });
        jPanel4.add(txtAPEPAT, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 90, 173, -1));

        jNombre1.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jNombre1.setForeground(new java.awt.Color(255, 255, 255));
        jNombre1.setText("Mascota");
        jPanel4.add(jNombre1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 150, -1, -1));

        jApellidoPaterno.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jApellidoPaterno.setForeground(new java.awt.Color(255, 255, 255));
        jApellidoPaterno.setText("Apellido Paterno");
        jPanel4.add(jApellidoPaterno, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 90, -1, -1));

        jNombre2.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jNombre2.setForeground(new java.awt.Color(255, 255, 255));
        jNombre2.setText("Nombre");
        jPanel4.add(jNombre2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 60, -1, -1));

        txtNOMBRE1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNOMBRE1ActionPerformed(evt);
            }
        });
        txtNOMBRE1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNOMBRE1KeyTyped(evt);
            }
        });
        jPanel4.add(txtNOMBRE1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 60, 173, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/IMAGEN0002.PNG"))); // NOI18N
        jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 20, 170, 170));

        jLabel2.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("TABLA CLIENTES");
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 180, -1));

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 820, 230));

        tblCliente.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        tblCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tblCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tblCliente.setGridColor(new java.awt.Color(204, 204, 204));
        tblCliente.setInheritsPopupMenu(true);
        tblCliente.setRowHeight(20);
        tblCliente.setSelectionBackground(new java.awt.Color(85, 119, 174));
        tblCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblClienteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblCliente);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 820, 210));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 490));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        buscar();
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
    nuevo();        // TODO add your handling code here:
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabarActionPerformed
    guarda(); // TODO add your handling code here:
    }//GEN-LAST:event_btnGrabarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
      try{
        Menu XCLIENTE = new Menu();
        XCLIENTE.setVisible(true);
        this.setVisible(false);
       }catch(Exception e){}
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        elimina();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
      actualiza();        // TODO add your handling code here:
    }//GEN-LAST:event_btnModificarActionPerformed

    private void txtCELULARKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCELULARKeyTyped
        char c = evt.getKeyChar();
        if(c<'0'|| c>'9') evt.consume();
    }//GEN-LAST:event_txtCELULARKeyTyped

    private void txtDIRECCIONKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDIRECCIONKeyTyped
         char c = evt.getKeyChar();
        if((c<'a'|| c>'z') && (c<'A'|| c>'Z')) evt.consume();
    }//GEN-LAST:event_txtDIRECCIONKeyTyped

    private void tblClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblClienteMouseClicked
        int sfil= tblCliente.getSelectedRow();
        
        int ruc=tblCliente.getValueAt(sfil,0).hashCode();
        String razon=tblCliente.getValueAt(sfil,1).toString();
        int telefono=tblCliente.getValueAt(sfil,2).hashCode();
        String direccion=tblCliente.getValueAt(sfil,3).toString();
        String condicion=tblCliente.getValueAt(sfil,4).toString();
        String rubro  = tblCliente.getValueAt(sfil,5).toString();
        
       
        txtDNI.setText(String.valueOf(ruc));
        txtAPEMAT.setText(razon);
        txtCELULAR.setText(String.valueOf(telefono));
        txtDIRECCION.setText(direccion);
        cboCondicion.setSelectedItem(condicion);
        cboRubro.setSelectedItem(rubro);
    }//GEN-LAST:event_tblClienteMouseClicked

    private void txtAPEMATKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtAPEMATKeyTyped
        char c = evt.getKeyChar();
        if((c<'a'|| c>'z') && (c<'A'|| c>'Z')) evt.consume();
    }//GEN-LAST:event_txtAPEMATKeyTyped

    private void txtAPEMATActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAPEMATActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAPEMATActionPerformed

    private void txtNOMBREActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNOMBREActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNOMBREActionPerformed

    private void txtNOMBREKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNOMBREKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNOMBREKeyTyped

    private void txtAPEPATActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAPEPATActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAPEPATActionPerformed

    private void txtAPEPATKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtAPEPATKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAPEPATKeyTyped

    private void txtNOMBRE1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNOMBRE1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNOMBRE1ActionPerformed

    private void txtNOMBRE1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNOMBRE1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNOMBRE1KeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmCliente().setVisible(true);
            }
        });
    }
    
    
    
    
    
    
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGrabar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jApellidoMaterno;
    private javax.swing.JLabel jApellidoPaterno;
    private javax.swing.JLabel jCelular;
    private javax.swing.JLabel jDireccion;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jNombre1;
    private javax.swing.JLabel jNombre2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblCliente;
    private javax.swing.JTextField txtAPEMAT;
    private javax.swing.JTextField txtAPEPAT;
    private javax.swing.JTextField txtCELULAR;
    private javax.swing.JTextField txtDIRECCION;
    private javax.swing.JTextField txtNOMBRE;
    private javax.swing.JTextField txtNOMBRE1;
    // End of variables declaration//GEN-END:variables
  
    public void llenaCondicion(){
       cboCondicion.addItem("Contado");

    }
    
public void nuevo() {
        txtDNI.setText("");
        txtAPEMAT.setText("");
        txtCELULAR.setText("");
        txtDIRECCION.setText("");
        this.cboCondicion.setSelectedIndex(0);
        this.cboRubro.setSelectedIndex(0);
        txtDNI.requestFocus();
    }

public void buscar() {

    
    int msg = JOptionPane.showConfirmDialog(this,"Deseas Buscar el Registro","Buscar",JOptionPane.YES_NO_OPTION);    
    if(msg == JOptionPane.YES_OPTION){
        Mascota a = icli.buscar(getRuc());
        if(a == null){
            JOptionPane.showMessageDialog(this,"No se encuentro!!!");
            this.txtDNI.requestFocus();
        }else{
            txtDNI.setText("" + a.getRuc());
            txtAPEMAT.setText(a.getRazon());
            txtCELULAR.setText("" +a.getTelefono());
            txtDIRECCION.setText(a.getDireccion());
            cboCondicion.setSelectedItem(a.getCondicion());          
        }
    }
    else{
    
    }
    
}

    public void guarda() {
        int msg = JOptionPane.showConfirmDialog(this, "Desea grabar el registro?", "Grabar", JOptionPane.YES_NO_OPTION);
        if (msg == JOptionPane.YES_OPTION) {
            Mascota a = new Mascota(getRuc(), getRazon(), getTelefono(), getDireccion(),getCondicion());
            icli.adicionar(a);
            icli.grabar();
            listar();
            JOptionPane.showMessageDialog(this, "Registro grabado!");
        } else {
            txtDNI.requestFocus();
            listar();
        }
    }

    public void actualiza() {
        int msg = JOptionPane.showConfirmDialog(this, "Desea actualizar el registro?", "Modificar", JOptionPane.YES_NO_OPTION);
        if (msg == JOptionPane.YES_OPTION) {
            Mascota a = icli.buscar(getRuc());
            if (a != null) {
                a.setRazon(txtAPEMAT.getText());
                a.setTelefono(Integer.parseInt(txtCELULAR.getText()));
                a.setDireccion(txtDIRECCION.getText());
                a.setCondicion(getCondicion());
                icli.grabar();
                listar();
            } else {
                JOptionPane.showMessageDialog(this, "No se encontro!", "Validación", 1);
            }
        }
    }

    public void elimina() {
        int msg = JOptionPane.showConfirmDialog(this, "Desea eliminar el registro?", "Eliminar", JOptionPane.YES_NO_OPTION);
        if (msg == JOptionPane.YES_OPTION) {
            Mascota a = icli.buscar(getRuc());
            if (a != null) {
                icli.eliminar(a);
                icli.grabar();
                listar();
            } else {
                JOptionPane.showMessageDialog(this, "No se encontro!", "Validación", 1);
            }
        }
    }

    public void listar() {
        if (icli.tamaño() == 0) {
            JOptionPane.showMessageDialog(this, "Archivo cliente sin registro!", "Validación", 1);
        } else {
            dtmCliente.setRowCount(0);
            for (int i = 0; i < icli.tamaño(); i++) {
                Object vec[] = new Object[6];
                vec[0] = icli.obtener(i).getRuc();
                vec[1] = icli.obtener(i).getRazon();
                vec[2] = icli.obtener(i).getTelefono();
                vec[3] = icli.obtener(i).getDireccion();
                vec[4] = icli.obtener(i).getCondicion();
                vec[5] = icli.obtener(i).getRubro();

                dtmCliente.addRow(vec);
            }

            tblCliente.setModel(dtmCliente);
        }
    }

    public void llenaColumna() {
        dtmCliente.addColumn("DNI");
        dtmCliente.addColumn("NOMBRE");
        dtmCliente.addColumn("Telefono");
        dtmCliente.addColumn("Direccion");
        dtmCliente.addColumn("Condicion");
        tblCliente.setModel(dtmCliente);
    }

    public int getRuc() {
        return Integer.parseInt(txtDNI.getText());
    }
    public String getRazon() {
        return txtAPEMAT.getText();
    }
    public int getTelefono() {
        return Integer.parseInt(txtCELULAR.getText());
    }
    public String getDireccion() {
        return txtDIRECCION.getText();
    }
      public String getCondicion() {
       return cboCondicion.getSelectedItem().toString();
    }
}




