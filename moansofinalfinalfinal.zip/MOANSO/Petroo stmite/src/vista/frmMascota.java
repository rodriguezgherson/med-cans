/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import Conexiones.Procedimientos;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author HP
 */
public class frmMascota extends javax.swing.JFrame {

    static ResultSet res;
 
    public frmMascota() {
        initComponents();
        CargarMascota();
    }
    
    public void CargarMascota(){
        DefaultTableModel TBMASCOTA = (DefaultTableModel) tblMascota.getModel();
        TBMASCOTA.setRowCount(0);
        res = Conexiones.Conexion.Consulta("select * from Mascota");
        try{
            while(res.next()){
                Vector v = new Vector();
                v.add(res.getInt(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getString(5));
                TBMASCOTA.addRow(v);
                tblMascota.setModel(TBMASCOTA);
            }
        }catch (SQLException e){
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        txtFECHANAC = new javax.swing.JTextField();
        jCelular = new javax.swing.JLabel();
        txtCOLORPELA = new javax.swing.JTextField();
        jApellidoMaterno = new javax.swing.JLabel();
        txtPESO = new javax.swing.JTextField();
        btnNuevo = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnGrabar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        txtRAZA = new javax.swing.JTextField();
        jNombre1 = new javax.swing.JLabel();
        jApellidoPaterno = new javax.swing.JLabel();
        jNombre2 = new javax.swing.JLabel();
        txtNOMBRE = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblMascota = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Segoe UI Emoji", 1, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("REGISTRO DE MASCOTAS");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 360, -1));

        jPanel4.setBackground(new java.awt.Color(36, 47, 65));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtFECHANAC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFECHANACActionPerformed(evt);
            }
        });
        txtFECHANAC.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtFECHANACKeyTyped(evt);
            }
        });
        jPanel4.add(txtFECHANAC, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 150, 170, 20));

        jCelular.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jCelular.setForeground(new java.awt.Color(255, 255, 255));
        jCelular.setText("Color de Pelaje");
        jPanel4.add(jCelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 180, -1, -1));

        txtCOLORPELA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCOLORPELAKeyTyped(evt);
            }
        });
        jPanel4.add(txtCOLORPELA, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 180, 170, -1));

        jApellidoMaterno.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jApellidoMaterno.setForeground(new java.awt.Color(255, 255, 255));
        jApellidoMaterno.setText("Peso");
        jPanel4.add(jApellidoMaterno, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, -1, 20));

        txtPESO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPESOActionPerformed(evt);
            }
        });
        txtPESO.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPESOKeyTyped(evt);
            }
        });
        jPanel4.add(txtPESO, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 120, 170, -1));

        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Nuevo_1.png"))); // NOI18N
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        jPanel4.add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 10, 100, 20));

        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Buscar_1.png"))); // NOI18N
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        jPanel4.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, 90, 20));

        btnGrabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Grabar_1.png"))); // NOI18N
        btnGrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabarActionPerformed(evt);
            }
        });
        jPanel4.add(btnGrabar, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 200, 80, 20));

        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Actualizar_1.png"))); // NOI18N
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        jPanel4.add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 10, 100, 20));

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Eliminar_2.png"))); // NOI18N
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel4.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 200, 90, 20));

        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Salir_2.png"))); // NOI18N
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        jPanel4.add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 10, 78, 20));

        txtRAZA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRAZAActionPerformed(evt);
            }
        });
        txtRAZA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtRAZAKeyTyped(evt);
            }
        });
        jPanel4.add(txtRAZA, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 90, 170, -1));

        jNombre1.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jNombre1.setForeground(new java.awt.Color(255, 255, 255));
        jNombre1.setText("Fecha Nacimiento");
        jPanel4.add(jNombre1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, -1, -1));

        jApellidoPaterno.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jApellidoPaterno.setForeground(new java.awt.Color(255, 255, 255));
        jApellidoPaterno.setText("Raza");
        jPanel4.add(jApellidoPaterno, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 90, -1, -1));

        jNombre2.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jNombre2.setForeground(new java.awt.Color(255, 255, 255));
        jNombre2.setText("Nombre");
        jPanel4.add(jNombre2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 60, -1, -1));

        txtNOMBRE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNOMBREActionPerformed(evt);
            }
        });
        txtNOMBRE.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNOMBREKeyTyped(evt);
            }
        });
        jPanel4.add(txtNOMBRE, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 60, 170, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/IMAGEN0004.PNG"))); // NOI18N
        jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 170, 170));

        jLabel2.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("TABLA MASCOTA");
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 180, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/PERRO1.jpg"))); // NOI18N
        jPanel4.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 40, 120, 160));

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 820, 230));

        tblMascota.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        tblMascota.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblMascota.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tblMascota.setGridColor(new java.awt.Color(204, 204, 204));
        tblMascota.setInheritsPopupMenu(true);
        tblMascota.setRowHeight(20);
        tblMascota.setSelectionBackground(new java.awt.Color(85, 119, 174));
        tblMascota.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblMascotaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblMascota);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 820, 210));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 840, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 840, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 490, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtFECHANACActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFECHANACActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFECHANACActionPerformed

    private void txtFECHANACKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtFECHANACKeyTyped
        
    }//GEN-LAST:event_txtFECHANACKeyTyped

    private void txtCOLORPELAKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCOLORPELAKeyTyped
       
    }//GEN-LAST:event_txtCOLORPELAKeyTyped

    private void txtPESOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPESOActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPESOActionPerformed

    private void txtPESOKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPESOKeyTyped
       
    }//GEN-LAST:event_txtPESOKeyTyped

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
    
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed

    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnGrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabarActionPerformed
        if(txtNOMBRE.getText().isEmpty() || txtRAZA.getText().isEmpty() || txtPESO.getText().isEmpty ||
            txtFECHANAC.getText().isEmpty() || txtCOLORPELA.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "META BIEN SUS DATOS", "Informacion", JOptionPane.INFORMATION_MESSAGE);
            txtNOMBRE.setText("");
            txtRAZA.setText("");
            txtPESO.setText("");
            txtFECHANAC.setText("");
            txtCOLORPELA.setText("");
            txtNOMBRE.setText("");
            txtRAZA.setText("");
            txtPESO.requestFocus();
            txtFECHANAC.requestFocus();
            txtCOLORPELA.requestFocus();
        } 
        else {
            try {
                res = Conexiones.Conexion.Consulta("Select COUNT(Nombremascota)from MEDICANS where Nombremascota='" + txtNOMBRE.getText() + "'");
                try{
                    while(res.next()){
                        cont = res.getInt(1);
                    }
                }catch (SQLException  e){
                }
                if(cont >= 1){
                    JOptionPane.showMessageDialog(this, "ESTE ELEMENTO YA EXISTE" , "Informacion", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    Procedimientos.EntradaMascota(txtNOMBRE.getText(),txtRAZA.getText(),txtPESO.getText(),
                            txtFECHANAC.getText(),txtCOLORPELA.getText());
                    txtNOMBRE.setText("");
                    txtRAZA.setText("");
                    txtPESO.setText("");
                    txtFECHANAC.setText("");
                    txtCOLORPELA.setText("");
                    txtNOMBRE.setText("");
                    txtRAZA.setText("");
                    txtPESO.requestFocus();
                    txtFECHANAC.requestFocus();
                    txtCOLORPELA.requestFocus();
                    JOptionPane.showMessageDialog(this, "LOS DATOS HAN SIGO GUARDADOS CORRECTAMENTE");
                }
            }catch (SQLException e){
            }
        }
    }//GEN-LAST:event_btnGrabarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
             // TODO add your handling code here:
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed

    }//GEN-LAST:event_btnSalirActionPerformed

    private void txtRAZAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRAZAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRAZAActionPerformed

    private void txtRAZAKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtRAZAKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRAZAKeyTyped

    private void txtNOMBREActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNOMBREActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNOMBREActionPerformed

    private void txtNOMBREKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNOMBREKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNOMBREKeyTyped

    private void tblMascotaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblMascotaMouseClicked

    }//GEN-LAST:event_tblMascotaMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmMascota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmMascota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmMascota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmMascota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmMascota().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGrabar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jApellidoMaterno;
    private javax.swing.JLabel jApellidoPaterno;
    private javax.swing.JLabel jCelular;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jNombre1;
    private javax.swing.JLabel jNombre2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblMascota;
    private javax.swing.JTextField txtCOLORPELA;
    private javax.swing.JTextField txtFECHANAC;
    private javax.swing.JTextField txtNOMBRE;
    private javax.swing.JTextField txtPESO;
    private javax.swing.JTextField txtRAZA;
    // End of variables declaration//GEN-END:variables
}
