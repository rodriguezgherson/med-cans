package vista;

import datos.Producto;
import dao.ProductoDAO;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class frmProducto extends javax.swing.JFrame {

    public frmProducto() {
        initComponents();
        llenarTabla();
    }

    void llenarTabla() {
//DefaultTableModel modelo=new DefaultTableModel();
        DefaultTableModel modelo = new DefaultTableModel();
        Producto pro = new Producto();
        ProductoDAO dao = new ProductoDAO();
        ArrayList<Producto> lista = new ArrayList<Producto>();
        lista = dao.ListarProducto();
        modelo.setRowCount(lista.size());
        Iterator it = lista.iterator();
        modelo.addColumn("Codigo");
        modelo.addColumn("Nombre");
        modelo.addColumn("Marca");
        modelo.addColumn("Cantidad");
        modelo.addColumn("Precio");
        modelo.addColumn("Unidad Medida");
        int i = 0;
        while (it.hasNext()) {
            Object obj = it.next();
            Producto p = (Producto) obj;
            modelo.setValueAt(p.getIDProducto(), i, 0);
            modelo.setValueAt(p.getNombreProducto(), i, 1);
            modelo.setValueAt(p.getIDMarca(), i, 2);
            modelo.setValueAt(p.getCantidad(), i, 3);
            modelo.setValueAt(p.getPrecio(), i, 4);
            modelo.setValueAt(p.getUnidadMedida(), i, 5);
            i++;
        }
        tblProducto.setModel(modelo);
    }

    /*private void ListarTabla() {
        ArrayList<Producto> listas = productos.ListarProducto();
        tblCliente.setModel(new TablaProducto(listas));
        tblCliente.getRowSorter();
    }

    public void Limpiar() {
        txtNOMBRE.setText("");
        txtMARCA.setText("");
        txtCANTIDAD.setText("");
        txtUNIDADMEDIDA.setText("");
        txtPRECIO.setText("");
    }*/
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        txtUNIDADMEDIDA = new javax.swing.JTextField();
        jCantidad = new javax.swing.JLabel();
        txtCANTIDAD = new javax.swing.JTextField();
        btnNuevo = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnGrabar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        txtMARCA = new javax.swing.JTextField();
        jCantidadMedidad = new javax.swing.JLabel();
        jMarca = new javax.swing.JLabel();
        jNombre = new javax.swing.JLabel();
        txtNOMBRE = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPrecio1 = new javax.swing.JLabel();
        txtPRECIO = new javax.swing.JTextField();
        btnModificar1 = new javax.swing.JButton();
        btnMarca = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblProducto = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(0, 0, 0));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Segoe UI Emoji", 1, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("REGISTRO DE PRODUCTOS");
        jPanel5.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 360, -1));

        jPanel6.setBackground(new java.awt.Color(36, 47, 65));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtUNIDADMEDIDA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUNIDADMEDIDAActionPerformed(evt);
            }
        });
        txtUNIDADMEDIDA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtUNIDADMEDIDAKeyTyped(evt);
            }
        });
        jPanel6.add(txtUNIDADMEDIDA, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 140, 170, 20));

        jCantidad.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jCantidad.setForeground(new java.awt.Color(255, 255, 255));
        jCantidad.setText("Cantidad");
        jPanel6.add(jCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 110, -1, 20));

        txtCANTIDAD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCANTIDADActionPerformed(evt);
            }
        });
        txtCANTIDAD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCANTIDADKeyTyped(evt);
            }
        });
        jPanel6.add(txtCANTIDAD, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 110, 170, -1));

        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Nuevo_1.png"))); // NOI18N
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        jPanel6.add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 10, 100, 20));

        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Buscar_1.png"))); // NOI18N
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        jPanel6.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, 90, 20));

        btnGrabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Grabar_1.png"))); // NOI18N
        btnGrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabarActionPerformed(evt);
            }
        });
        jPanel6.add(btnGrabar, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 200, 90, 20));

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Eliminar_2.png"))); // NOI18N
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel6.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 200, 90, 20));

        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Salir_2.png"))); // NOI18N
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        jPanel6.add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 10, 78, 20));

        txtMARCA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMARCAActionPerformed(evt);
            }
        });
        txtMARCA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtMARCAKeyTyped(evt);
            }
        });
        jPanel6.add(txtMARCA, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 80, 170, -1));

        jCantidadMedidad.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jCantidadMedidad.setForeground(new java.awt.Color(255, 255, 255));
        jCantidadMedidad.setText("Unidad de Medida");
        jPanel6.add(jCantidadMedidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, -1, -1));

        jMarca.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jMarca.setForeground(new java.awt.Color(255, 255, 255));
        jMarca.setText("Marca");
        jPanel6.add(jMarca, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 80, -1, -1));

        jNombre.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jNombre.setForeground(new java.awt.Color(255, 255, 255));
        jNombre.setText("Nombre");
        jPanel6.add(jNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 50, -1, -1));

        txtNOMBRE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNOMBREActionPerformed(evt);
            }
        });
        txtNOMBRE.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNOMBREKeyTyped(evt);
            }
        });
        jPanel6.add(txtNOMBRE, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 50, 170, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/IMAGEN0001.PNG"))); // NOI18N
        jPanel6.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 20, 170, 170));

        jLabel2.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("TABLA PRODUCTO");
        jPanel6.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 180, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/atencion11.PNG"))); // NOI18N
        jPanel6.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 30, 150, 170));

        jPrecio1.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jPrecio1.setForeground(new java.awt.Color(255, 255, 255));
        jPrecio1.setText("Precio");
        jPanel6.add(jPrecio1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, -1, -1));

        txtPRECIO.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPRECIOKeyTyped(evt);
            }
        });
        jPanel6.add(txtPRECIO, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 170, 170, -1));

        btnModificar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Actualizar_1.png"))); // NOI18N
        btnModificar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificar1ActionPerformed(evt);
            }
        });
        jPanel6.add(btnModificar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 10, 100, 20));

        btnMarca.setBackground(new java.awt.Color(153, 255, 255));
        btnMarca.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 18)); // NOI18N
        btnMarca.setText("Codigos");
        btnMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMarcaActionPerformed(evt);
            }
        });
        jPanel6.add(btnMarca, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 80, 90, 20));

        jPanel5.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 820, 230));

        tblProducto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tblProducto);

        jPanel5.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 820, 210));

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 490));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtUNIDADMEDIDAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUNIDADMEDIDAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUNIDADMEDIDAActionPerformed

    private void txtUNIDADMEDIDAKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtUNIDADMEDIDAKeyTyped

    }//GEN-LAST:event_txtUNIDADMEDIDAKeyTyped

    private void txtCANTIDADActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCANTIDADActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCANTIDADActionPerformed

    private void txtCANTIDADKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCANTIDADKeyTyped

    }//GEN-LAST:event_txtCANTIDADKeyTyped

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed

    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnGrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabarActionPerformed
        ProductoDAO dao = new ProductoDAO();
        DefaultTableModel modelo = new DefaultTableModel();
        Producto p = new Producto();
        ArrayList<Producto> lista = new ArrayList<Producto>();
        p.setNombreProducto(txtNOMBRE.getText());
        p.setPrecio(txtPRECIO.getText());
        //lista=dao.ConsultarPro(txtText.getText());
        lista = dao.InsertarProducto(p);
        modelo.setRowCount(lista.size());
        Iterator it = lista.iterator();
        modelo.addColumn("Codigo");
        modelo.addColumn("Des");
        modelo.addColumn("Can");
        modelo.addColumn("Oferta");
        int i = 0;
        while (it.hasNext()) {
            Object obj = it.next();
            Producto pr = (Producto) obj;
            modelo.setValueAt(pr.getCod(), i, 0);
            modelo.setValueAt(pr.getDes(), i, 1);
            modelo.setValueAt(pr.getCan(), i, 2);
            modelo.setValueAt(pr.getOferta(), i, 3);
            i++;
        }
        tblCliente.setModel(modelo);
// TODO add your handling code here:
    }//GEN-LAST:event_btnGrabarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        /*boolean resp = personas.DeletePersona(per);
        if (resp == false) {
            JOptionPane.showMessageDialog(null, "Dato Actualizado");
            ListarTabla();
            Limpiar();
        } else {
            JOptionPane.showMessageDialog(null, "Dato no Actualizado");
        }*/
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed

    }//GEN-LAST:event_btnSalirActionPerformed

    private void txtMARCAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMARCAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMARCAActionPerformed

    private void txtMARCAKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtMARCAKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMARCAKeyTyped

    private void txtNOMBREActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNOMBREActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNOMBREActionPerformed

    private void txtNOMBREKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNOMBREKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNOMBREKeyTyped

    private void txtPRECIOKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPRECIOKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPRECIOKeyTyped

    private void btnModificar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnModificar1ActionPerformed

    private void btnMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMarcaActionPerformed
        this.setVisible(false);
        frmMarca Marca = new frmMarca();
        Marca.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_btnMarcaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                

}
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmProducto.class
.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        

} catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmProducto.class
.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        

} catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmProducto.class
.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        

} catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmProducto.class
.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmProducto().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGrabar;
    private javax.swing.JButton btnMarca;
    private javax.swing.JButton btnModificar1;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jCantidad;
    private javax.swing.JLabel jCantidadMedidad;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jMarca;
    private javax.swing.JLabel jNombre;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JLabel jPrecio1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable tblProducto;
    private javax.swing.JTextField txtCANTIDAD;
    private javax.swing.JTextField txtMARCA;
    private javax.swing.JTextField txtNOMBRE;
    private javax.swing.JTextField txtPRECIO;
    private javax.swing.JTextField txtUNIDADMEDIDA;
    // End of variables declaration//GEN-END:variables
}