package Conexiones;

import java.sql.CallableStatement;
import java.sql.SQLException;

public class Procedimientos {
 
    public static void EntradaMascota(String a, String b, String c, String d)throws SQLException{
        CallableStatement entrada = Conexion.getConexion().prepareCall("{call EntradaMascota(?,?,?)}");
        entrada.setString(1, a);
        entrada.setString(2, b);
        entrada.setString(3, c);
        entrada.setString(4, d);
        entrada.execute();
    }

    public static void EntradaMascota(String text, String text0, String text1, String text2, String text3) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
        
}
    
    
    
    
    
    
    
}
