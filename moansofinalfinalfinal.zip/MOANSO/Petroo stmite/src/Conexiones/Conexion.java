
package Conexiones;

import java.sql.*;

public class Conexion {

    public static Connection getConexion() {
        Connection cnx = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            cnx = DriverManager.getConnection("jdbc:sqlserver://localhost;"
                    + "databaseName=MEDICANS;user=sa;password=12345678");
            System.out.println("funca");
        } catch (Exception e) {
            System.out.println("hector Error: " + e);
        }
        return cnx;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        getConexion();
        
    }

}
