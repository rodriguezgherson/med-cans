package datos;

public class Marca {
    private int IDMarca;
    private String NombreMarca;
    
    public Marca(){
    }

    public Marca(int IDMarca, String NombreMarca) {
        this.IDMarca = IDMarca;
        this.NombreMarca = NombreMarca;
    }

    public int getIDMarca() {
        return IDMarca;
    }

    public void setIDMarca(int IDMarca) {
        this.IDMarca = IDMarca;
    }

    public String getNombreMarca() {
        return NombreMarca;
    }

    public void setNombreMarca(String NombreMarca) {
        this.NombreMarca = NombreMarca;
    } 
}
