package datos;

public class VentaProducto {
    private int IDVentas;
    private String NombreProducto;
    private String NombreCliente;
    private String ApellidoCliente;
    private String FechaVentaProducto;
    private float PrecioTotal;
    
    public VentaProducto() {
    }

    public VentaProducto(int IDVentas, String NombreProducto, String NombreCliente, String ApellidoCliente, String FechaVentaProducto, float PrecioTotal) {
        this.IDVentas = IDVentas;
        this.NombreProducto = NombreProducto;
        this.NombreCliente = NombreCliente;
        this.ApellidoCliente = ApellidoCliente;
        this.FechaVentaProducto = FechaVentaProducto;
        this.PrecioTotal = PrecioTotal;
    }

    public int getIDVentas() {
        return IDVentas;
    }

    public void setIDVentas(int IDVentas) {
        this.IDVentas = IDVentas;
    }

    public String getNombreProducto() {
        return NombreProducto;
    }

    public void setNombreProducto(String NombreProducto) {
        this.NombreProducto = NombreProducto;
    }

    public String getNombreCliente() {
        return NombreCliente;
    }

    public void setNombreCliente(String NombreCliente) {
        this.NombreCliente = NombreCliente;
    }

    public String getApellidoCliente() {
        return ApellidoCliente;
    }

    public void setApellidoCliente(String ApellidoCliente) {
        this.ApellidoCliente = ApellidoCliente;
    }

    public String getFechaVentaProducto() {
        return FechaVentaProducto;
    }

    public void setFechaVentaProducto(String FechaVentaProducto) {
        this.FechaVentaProducto = FechaVentaProducto;
    }

    public float getPrecioTotal() {
        return PrecioTotal;
    }

    public void setPrecioTotal(float PrecioTotal) {
        this.PrecioTotal = PrecioTotal;
    }
  
}
