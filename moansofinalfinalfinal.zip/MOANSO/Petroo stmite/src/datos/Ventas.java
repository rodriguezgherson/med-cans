package datos;

public class Ventas {
    private int IDVentas;
    private String IDProducto;
    private String NombreCliente;
    private String ApellidoCliente;
    private String FechaVenta;
    private float PrecioTotal;
    
    public Ventas() {
    }

    public Ventas(int IDVentas, String IDProducto, String NombreCliente, String ApellidoCliente, String FechaVenta, float PrecioTotal) {
        this.IDVentas = IDVentas;
        this.IDProducto = IDProducto;
        this.NombreCliente = NombreCliente;
        this.ApellidoCliente = ApellidoCliente;
        this.FechaVenta = FechaVenta;
        this.PrecioTotal = PrecioTotal;
    }

    public int getIDVentas() {
        return IDVentas;
    }

    public void setIDVentas(int IDVentas) {
        this.IDVentas = IDVentas;
    }

    public String getIDProducto() {
        return IDProducto;
    }

    public void setIDProducto(String IDProducto) {
        this.IDProducto = IDProducto;
    }

    public String getNombreCliente() {
        return NombreCliente;
    }

    public void setNombreCliente(String NombreCliente) {
        this.NombreCliente = NombreCliente;
    }

    public String getApellidoCliente() {
        return ApellidoCliente;
    }

    public void setApellidoCliente(String ApellidoCliente) {
        this.ApellidoCliente = ApellidoCliente;
    }

    public String getFechaVenta() {
        return FechaVenta;
    }

    public void setFechaVenta(String FechaVenta) {
        this.FechaVenta = FechaVenta;
    }

    public float getPrecioTotal() {
        return PrecioTotal;
    }

    public void setPrecioTotal(float PrecioTotal) {
        this.PrecioTotal = PrecioTotal;
    }
}
