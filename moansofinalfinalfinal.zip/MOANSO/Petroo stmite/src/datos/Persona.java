/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;
public class Persona {
    private int ID;
    private String Nombre;
    private String ApellidoPat;
    private String ApellidoMat;
    private String Direccion;
    private int Celular;
    private char Sexo;

    public Persona() {
    }

    public Persona(int ID, String Nombre, String ApellidoPat, String ApellidoMat, String Direccion, int Celular, char Sexo) {
        this.ID = ID;
        this.Nombre = Nombre;
        this.ApellidoPat = ApellidoPat;
        this.ApellidoMat = ApellidoMat;
        this.Direccion = Direccion;
        this.Celular = Celular;
        this.Sexo = Sexo;
    }
}
    
    
    
    
    
    
   