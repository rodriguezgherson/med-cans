package datos;

public class User {
    
   private String User;
   private String Pass;
   private String Tipo;
   public User(String user, String pass, String tipo) {
        this.User = user;
        this.Pass = pass;
        this.Tipo = tipo;
    
   }
    public String getUser() {
        return User;
    }

    public void setUser(String User) {
        this.User = User;
    }

    public String getPass() {
        return Pass;
    }

    public void setPass(String Pass) {
        this.Pass = Pass;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    
}