package datos;


public class VentaAtencion {
   private int IDVentAtencion;
   private String NombreMascota;
   private String NombreAtencion;
   private String FechaVentaAtencion;
   private float PrecioTotal;
   
   public VentaAtencion(){
   }

    public VentaAtencion(int IDVentAtencion, String NombreMascota, String NombreAtencion, String FechaVentaAtencion, float PrecioTotal) {
        this.IDVentAtencion = IDVentAtencion;
        this.NombreMascota = NombreMascota;
        this.NombreAtencion = NombreAtencion;
        this.FechaVentaAtencion = FechaVentaAtencion;
        this.PrecioTotal = PrecioTotal;
    }

    public int getIDVentAtencion() {
        return IDVentAtencion;
    }

    public void setIDVentAtencion(int IDVentAtencion) {
        this.IDVentAtencion = IDVentAtencion;
    }

    public String getNombreMascota() {
        return NombreMascota;
    }

    public void setNombreMascota(String NombreMascota) {
        this.NombreMascota = NombreMascota;
    }

    public String getNombreAtencion() {
        return NombreAtencion;
    }

    public void setNombreAtencion(String NombreAtencion) {
        this.NombreAtencion = NombreAtencion;
    }

    public String getFechaVentaAtencion() {
        return FechaVentaAtencion;
    }

    public void setFechaVentaAtencion(String FechaVentaAtencion) {
        this.FechaVentaAtencion = FechaVentaAtencion;
    }

    public float getPrecioTotal() {
        return PrecioTotal;
    }

    public void setPrecioTotal(float PrecioTotal) {
        this.PrecioTotal = PrecioTotal;
    }
}
