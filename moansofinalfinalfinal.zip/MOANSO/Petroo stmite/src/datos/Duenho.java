package datos;

public class Duenho {
    private int IDPersona;
    private String Nombre;
    private String ApellidoPat;
    private String ApellidoMat;
    private String Direccion;
    private int Celular;
    private int IDMascota;

    public Duenho() {
    }

    public Duenho(int IDPersona, String Nombre, String ApellidoPat, String ApellidoMat, String Direccion, int Celular, int IDMascota) {
        this.IDPersona = IDPersona;
        this.Nombre = Nombre;
        this.ApellidoPat = ApellidoPat;
        this.ApellidoMat = ApellidoMat;
        this.Direccion = Direccion;
        this.Celular = Celular;
        this.IDMascota = IDMascota;
    }

    public int getIDPersona() {
        return IDPersona;
    }

    public void setIDPersona(int IDPersona) {
        this.IDPersona = IDPersona;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellidoPat() {
        return ApellidoPat;
    }

    public void setApellidoPat(String ApellidoPat) {
        this.ApellidoPat = ApellidoPat;
    }

    public String getApellidoMat() {
        return ApellidoMat;
    }

    public void setApellidoMat(String ApellidoMat) {
        this.ApellidoMat = ApellidoMat;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public int getCelular() {
        return Celular;
    }

    public void setCelular(int Celular) {
        this.Celular = Celular;
    }

    public int getIDMascota() {
        return IDMascota;
    }

    public void setIDMascota(int IDMascota) {
        this.IDMascota = IDMascota;
    }

   

}