package datos;

public class Atencion {
    private int IDAtencion;
    private String NombreAtencion;
    private float PrecioAtencion;
    
    public Atencion(){
    }

    public Atencion(int IDAtencion, String NombreAtencion, float PrecioAtencion) {
        this.IDAtencion = IDAtencion;
        this.NombreAtencion = NombreAtencion;
        this.PrecioAtencion = PrecioAtencion;
    }

    public int getIDAtencion() {
        return IDAtencion;
    }

    public void setIDAtencion(int IDAtencion) {
        this.IDAtencion = IDAtencion;
    }

    public String getNombreAtencion() {
        return NombreAtencion;
    }

    public void setNombreAtencion(String NombreAtencion) {
        this.NombreAtencion = NombreAtencion;
    }

    public float getPrecioAtencion() {
        return PrecioAtencion;
    }

    public void setPrecioAtencion(float PrecioAtencion) {
        this.PrecioAtencion = PrecioAtencion;
    }
}
