package datos;

public class Mascota {
    private int IDMascota ;
    private String NombreMascota;
    private String Sexo;
    private String Raza;
    private float Peso ;
    private String FechaNacimiento;
    private String ColorPelaje;
   
    public Mascota (){
    }

    public Mascota(int IDMascota, String NombreMascota, String Sexo, String Raza, float Peso, String FechaNacimiento, String ColorPelaje) {
        this.IDMascota = IDMascota;
        this.NombreMascota = NombreMascota;
        this.Sexo = Sexo;
        this.Raza = Raza;
        this.Peso = Peso;
        this.FechaNacimiento = FechaNacimiento;
        this.ColorPelaje = ColorPelaje;
    }

    public int getIDMascota() {
        return IDMascota;
    }

    public void setIDMascota(int IDMascota) {
        this.IDMascota = IDMascota;
    }

    public String getNombreMascota() {
        return NombreMascota;
    }

    public void setNombreMascota(String NombreMascota) {
        this.NombreMascota = NombreMascota;
    }

    public String getSexo() {
        return Sexo;
    }

    public void setSexo(String Sexo) {
        this.Sexo = Sexo;
    }

    public String getRaza() {
        return Raza;
    }

    public void setRaza(String Raza) {
        this.Raza = Raza;
    }

    public float getPeso() {
        return Peso;
    }

    public void setPeso(float Peso) {
        this.Peso = Peso;
    }

    public String getFechaNacimiento() {
        return FechaNacimiento;
    }

    public void setFechaNacimiento(String FechaNacimiento) {
        this.FechaNacimiento = FechaNacimiento;
    }

    public String getColorPelaje() {
        return ColorPelaje;
    }

    public void setColorPelaje(String ColorPelaje) {
        this.ColorPelaje = ColorPelaje;
    }
    

    
}
