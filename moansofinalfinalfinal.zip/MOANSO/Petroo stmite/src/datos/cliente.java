/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;
public class cliente {
    private int ruc ;
    private String razon;
    private int telefono;
    private String direccion;
    private String condicion;
    private String rubro;
    
    public cliente (int ruc ,String razon, int telefono, String direccion, String condicion, String rubro ){
      
      this.ruc =ruc;
      this.razon = razon;
      this.telefono = telefono;
      this.direccion = direccion;
      this.condicion = condicion;
      this.rubro = rubro;
    }

    public cliente(int ruc, String razon, int telefono, String direccion, String condicion) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public int getRuc() {
        return ruc;
    }
    public void setRuc(int ruc) {
        this.ruc = ruc;
    }
    public String getRazon() {
        return razon;
    }
    public void setRazon(String razon) {
        this.razon = razon;
    }
    public int getTelefono() {
        return telefono;
    }
    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }
    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    public String getCondicion() {
        return condicion;
    }
    public void setCondicion(String condicion) {
        this.condicion = condicion;
    }

    public String getRubro() {
        return rubro;
    }
    public void setRubro(String rubro) {
        this.rubro = rubro;
    }
    
}
