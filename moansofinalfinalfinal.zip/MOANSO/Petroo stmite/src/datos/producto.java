package datos;

public class Producto {
    private int  IDProducto;
    private String NombreProducto;
    private int  IDMarca;
    private int Cantidad;
    private float Precio;
    private String UnidadMedida;
   
    public Producto() {
    }

    public Producto(int IDProducto, String NombreProducto, int IDMarca, int Cantidad, float Precio, String UnidadMedida) {
        this.IDProducto = IDProducto;
        this.NombreProducto = NombreProducto;
        this.IDMarca = IDMarca;
        this.Cantidad = Cantidad;
        this.Precio = Precio;
        this.UnidadMedida = UnidadMedida;
    }

    public int getIDProducto() {
        return IDProducto;
    }

    public void setIDProducto(int IDProducto) {
        this.IDProducto = IDProducto;
    }

    public String getNombreProducto() {
        return NombreProducto;
    }

    public void setNombreProducto(String NombreProducto) {
        this.NombreProducto = NombreProducto;
    }

    public int getIDMarca() {
        return IDMarca;
    }

    public void setIDMarca(int IDMarca) {
        this.IDMarca = IDMarca;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }

    public float getPrecio() {
        return Precio;
    }

    public void setPrecio(float Precio) {
        this.Precio = Precio;
    }

    public String getUnidadMedida() {
        return UnidadMedida;
    }

    public void setUnidadMedida(String UnidadMedida) {
        this.UnidadMedida = UnidadMedida;
    }

    
}


   
    
    
  
