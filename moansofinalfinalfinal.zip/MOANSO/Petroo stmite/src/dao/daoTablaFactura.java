/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import datos.tablafactura;
import java.io.*;//Libreria para archivos
import java.util.ArrayList;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author Andr Es
 */
public class daoTablaFactura {
    private ArrayList<tablafactura> Fac;
    private String Archivo;//Nombre del Archivo
  
   
    public daoTablaFactura(String Archivo){
      Fac = new ArrayList<tablafactura>();
      this.Archivo = Archivo;
      cargar();
    }
    //Agregar Elementos a la lista  - coleccion
    public void adicionar(tablafactura f){
       Fac.add(f);
    }
    public int tamaño(){
      return Fac.size();
    }
    //Metodo para buscar objetos por codigo
    public tablafactura buscarTabla(int codigo){
       for(int i=0;i<tamaño();i++){
           if(codigo==Fac.get(i).getCodigo())
                return Fac.get(i);
       }    
       return null;
    }

     /*Correlativo*/
    public int getCorrelativo(){
       /*ArrayList vacio  1  2  3  4*/
       if(tamaño() == 0)
           return 1;
       else{
          return tamaño() + 1;
       }
    }
    public int getCorrelativo1(){
       /*ArrayList vacio  1  2  3  4*/
       if(tamaño() == 0)
           return 100001;
       else{
          return tamaño() + 1;
       }
    }
      public void eliminar(tablafactura a) {
        Fac.remove(a);
    }
    
    
   
    public tablafactura obtener(int i){
       return Fac.get(i);
    }
    /*Implementar Archivos*/
    public void grabar(){
      try{  
         PrintWriter pw;
         String linea;
         pw = new PrintWriter(new FileWriter(Archivo));         
         for(int i=0;i<tamaño();i++){
             linea = (
                     obtener(i).getCantidad()+ ";" +
                     obtener(i).getCodigo() + ";" +
                     obtener(i).getDescripcion()+ ";" +
                     obtener(i).getPrecio()); 
             pw.println(linea); 
         }  
         pw.close();
      }
      catch(Exception e){
         System.out.println(e.getMessage());
      }      
    }
    public void cargar(){
    try{
       BufferedReader br;
       String linea = null;
       String[] array = null;
       br = new BufferedReader(new FileReader(Archivo));
       
       while((linea = br.readLine())!= null){
         array = linea.split(";");
         tablafactura f = new tablafactura (
                
                 
                 Integer.parseInt(array[0].trim()),
                 Integer.parseInt(array[1].trim()),
                 array[2].trim(),Double.parseDouble(array[3].trim())
                 );
                 
         adicionar(f);
       }
       br.close();
    }
    catch(Exception e){
      System.out.println(e.getMessage());
    }
    }
}
