package dao;

import java.util.*;
import datos.Producto;
import Conexiones.Conexion;

public class PersonaDAO {

    ConexionDB conexion = new ConexionDB();

    public ArrayList<Productos> ConsultarPro(Productos des) {
        Connection con = null;
        CallableStatement cstm = null;
        ArrayList<Productos> lista = new ArrayList<Productos>();
        try {
            con = ConexionDB.getConexion();
            cstm = con.prepareCall("{Call usp_ListaProductos(?)}");
            cstm.setString("des", des.getDes());
            ResultSet rs = cstm.executeQuery();
            Productos p;
            while (rs.next()) {
                p = new Productos(rs.getString(1),
                        rs.getString(2), rs.getInt(3),
                        rs.getString(4));
                lista.add(p);
            }
        } catch (Exception e) {
            System.out.print(e);
        }
        return lista;
    }

}
