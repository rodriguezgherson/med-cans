package dao;

import java.util.*;
import java.sql.*;
import datos.Atencion;
import Conexiones.Conexion;

public class AtencionDAO {
     public ArrayList<Atencion> ListarMarca() {
        Connection con = null;
        CallableStatement cstm = null;

        ArrayList<Atencion> lista = new ArrayList<Atencion>();
        try {
            con = Conexion.getConexion();
            cstm = con.prepareCall("{Call ListaAtencion()}");
            //cstm.setString("country", country.getCountry());
            ResultSet rs = cstm.executeQuery();

            Atencion ate;
            while (rs.next()) {
                 ate = new Atencion(rs.getInt(1),rs.getString(2),rs.getFloat(3));
                lista.add(ate);
            }
        } catch (Exception e) {
            System.out.print(e);
        }
        return lista;
    }
}
