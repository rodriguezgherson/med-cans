
package dao;

import Conexiones.Conexion;
import datos.Persona;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PersonaSQLDAO implements PersonaDAO {
    Conexion dbconn;

    public PersonaSQLDAO() {
        dbconn = new Conexion();
        dbconn = setUrl("");
        dbconn = setLogin("sa");
        dbconn = setPassword("1234");
        dbconn = setDriver("com.microsoft.sqlserver.jdbc.SQLServerDriver");
    }
    
    public List<Persona>getPersonas(){
        List<Persona> lista = new ArrayList<>();
        try{
            Statement st = conn.createStatement();
            String rq = "SELECT ID,Nombre,ApellidoPat,ApellidoMat,Direccion,Celular,Sexo FROM CLIENTE ORDER BY ID";
            ResultSet rs = st.executeQuery(rq);
            while(rs.next()){
                  lista.add(new Persona(Interger.parseInt(rs.getString(1)),rs.getString(2),rs.getString(3),
                          rs.getString(4),rs.getString(5),rs.getString(6)));
            }
            dbconn.Desconectar();
            }catch (SQLException e){
                e.printStackTrace();
            }
        }    

    private Conexion setUrl(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private Conexion setLogin(String sa) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private Conexion setPassword(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
        }
    };
    public Persona getPersonaPorID (int ID){
        return null;
    };
    public List<Persona>getPersonasPorNombre(String nombre){
        return null;
    }

    private Conexion setUrl(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private Conexion setLogin(String sa) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private Conexion setPassword(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private Conexion setDriver(String commicrosoftsqlserverjdbcSQLServerDriver) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
