
package dao;

import java.util.*;
import java.sql.*;
import datos.Marca;
import Conexiones.Conexion;

public class MarcaDAO {
    
    public ArrayList<Marca> ListarMarca() {
        Connection con = null;
        CallableStatement cstm = null;

        ArrayList<Marca> lista = new ArrayList<Marca>();
        try {
            con = Conexion.getConexion();
            cstm = con.prepareCall("{Call ListaMarca()}");
            //cstm.setString("country", country.getCountry());
            ResultSet rs = cstm.executeQuery();

            Marca mar;
            while (rs.next()) {
                mar = new Marca(rs.getInt(1),rs.getString(2));
                lista.add(mar);
            }
        } catch (Exception e) {
            System.out.print(e);
        }
        return lista;
    }
}