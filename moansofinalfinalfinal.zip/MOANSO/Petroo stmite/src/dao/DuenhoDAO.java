
package dao;

import Conexiones.Conexion;
import datos.Duenho;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DuenhoDAO {
    public ArrayList<Duenho> ListarDuenho() {
       ArrayList<Duenho> lista = new ArrayList<>();
        try {
            PreparedStatement psta = Conexion.getConexion().
               prepareStatement("SELECT * FROM DUENHO");
            ResultSet rs = psta.executeQuery();
            
            while(rs.next()){
                Duenho duen =new Duenho(rs.getInt(1),
                        rs.getString(2), rs.getString(3),rs.getString(4),
                        rs.getString(5), rs.getString(6),rs.getInt(7),rs.getInt(8));
                lista.add(duen);
            }
        } catch (Exception e){}
            return lista;
    }
    public ArrayList<Duenho> ConsultarDuen(String NombreDuenho) {
        ArrayList<Duenho> lista = new ArrayList<>();
        try {
            PreparedStatement psta = Conexion.getConexion().
               prepareStatement("SELECT * FROM DUENHO WHERE NOMBRE_DUENHO=?");
            psta.setString(1, NombreDuenho);
            ResultSet rs = psta.executeQuery();
            
            while(rs.next()){
                Duenho duen;
                duen = new Duenho(rs.getInt(1),
                        rs.getString(2), rs.getString(3),rs.getString(4),
                        rs.getString(5), rs.getInt(6),rs.getInt(7));
                lista.add(duen);
            }
        } catch (Exception e){}
            return lista;
    }
    public ArrayList<Duenho> InsertarDuen(String NombreDuenho,String ApellidoPat,String ApellidoMat,String Direccion,int Celular,int IDMascota){
        try {
            PreparedStatement psta = Conexion.getConexion().
               prepareStatement("INSERT INTO MASCOTA VALUES (?,?,?,?,?,?)");
            psta.setString(1, NombreDuenho);
            psta.setString(2, ApellidoPat);
            psta.setString(3, ApellidoMat);
            psta.setString(4, Direccion);
            psta.setInt(5, Celular);
            psta.setInt(6, IDMascota);
            
            psta.executeQuery();
            }catch(Exception e){}
        return null;
    }
    public ArrayList<Duenho> ModificarDuen(int Celular,String Direccion,int IDDuenho,String NombreDuenho) {
        try {
            PreparedStatement psta = Conexion.getConexion().
            prepareStatement("UPDATE DUENHO SET CELULAR=? OR DIRECCION=? WHERE ID_DUENHO=? OR NOMBRE_DUENHO=? ");
            psta.setInt(1, Celular);
            psta.setString(2, Direccion);
            psta.setInt(3, IDDuenho);
            psta.setString(4, NombreDuenho);
            
            psta.executeQuery();
            }catch(Exception e){}
        return null;
    }  
    public ArrayList<Duenho> EliminarDuen(int IDDuenho,String NombreDuenho) {
        try {
            PreparedStatement psta = Conexion.getConexion().
            prepareStatement("DELETE DUENHO WHERE ID_MASCOTA=? OR NOMBRE_MASCOTA=? ");
            psta.setInt(1, IDDuenho);
            psta.setString(2, NombreDuenho);
            
            psta.executeQuery();
            }catch(Exception e){}
        return null;
    } 
}
