package dao;
import datos.factura;
import java.io.*;//Libreria para archivos
import java.util.ArrayList;
import java.text.ParseException;
import java.text.SimpleDateFormat;


public class daoFactura {
    private ArrayList<factura> Fac;
    private String Archivo;//Nombre del Archivo
  
    public daoFactura(){
      Fac = new ArrayList<factura>();
      cargar();
    }
    public daoFactura(String Archivo){
      Fac = new ArrayList<factura>();
      this.Archivo = Archivo;
      cargar();
    }
    //Agregar Elementos a la lista  - coleccion
    public void adicionar(factura f){
       Fac.add(f);
    }
    public int tamaño(){
      return Fac.size();
    }
    //Metodo para buscar objetos por codigo
    public factura buscarfactura(String numero){
       for(int i=0;i<tamaño();i++){
           if(Fac.get(i).getNumero().equals(numero))
                return Fac.get(i);
       }    
       return null;
    }
    public factura buscarFactura(int serie){
       for(int i=0;i<tamaño();i++){
           if(Fac.get(i).getSerie() == serie)
                return Fac.get(i);
       }    
       return null;
    }
     /*Correlativo*/
    public int getCorrelativo(){
       /*ArrayList vacio  1  2  3  4*/
       if(tamaño() == 0)
           return 1;
       else{
          return tamaño() + 1;
       }
    }
    public int getCorrelativo1(){
       /*ArrayList vacio  1  2  3  4*/
       if(tamaño() == 0)
           return 100001;
       else{
          return tamaño() + 1;
       }
    }
    
    
    
   
    public factura obtener(int i){
       return Fac.get(i);
    }
    public void eliminar(factura a) {
        Fac.remove(a);
    }
    /*Implementar Archivos*/
    public void grabar(){
      try{  
         PrintWriter pw;
         String linea;
         pw = new PrintWriter(new FileWriter(Archivo));         
         for(int i=0;i<tamaño();i++){
             linea = (Fac.get(i).getSerie() + ";" +
                     obtener(i).getNumero() + ";" +
                     obtener(i).getDireccion()+ ";" +
                     obtener(i).getRazon() + ";" +
                     obtener(i).getRuc()+ ";" +
                     obtener(i).getEstado() + ";" +
                     obtener(i).getCantidad()+ ";" +
                     obtener(i).getCodigo() + ";" +
                     obtener(i).getDescripcion()+ ";" +
                     obtener(i).getPrecio()+ ";" +
                     obtener(i).getFecha()+ ";" +
                     obtener(i).getHora()+ ";" +
                     obtener(i).getSubTotal()+ ";" +
                     obtener(i).getIGV()+ ";" +
                     obtener(i).getTotal()); 
             pw.println(linea); 
         }  
         pw.close();
      }
      catch(Exception e){
         System.out.println(e.getMessage());
      }      
    }
    public void cargar(){
    try{
       BufferedReader br;
       String linea = null;
       String[] array = null;
       br = new BufferedReader(new FileReader(Archivo));
       
       while((linea = br.readLine())!= null){
         array = linea.split(";");
         factura f = new factura (
                 Integer.parseInt(array[0].trim()),
                 (array[1].trim()),
                 array[2].trim(),array[3].trim(),
                 array[4].trim(),array[5].trim(),
                 Integer.parseInt(array[6].trim()),
                 Integer.parseInt(array[7].trim()),
                 array[8].trim(),Double.parseDouble(array[9].trim()),
                 array[10].trim(),array[11].trim(),
         array[12].trim(),
                 array[13].trim(),array[14].trim());
                 
         adicionar(f);
       }
       br.close();
    }
    catch(Exception e){
      System.out.println(e.getMessage());
    }
    }
}
