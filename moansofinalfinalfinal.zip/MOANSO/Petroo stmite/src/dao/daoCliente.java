
package dao;
import java.io.*;
import java.util.ArrayList;
import datos.Mascota;
public class daoCliente {
    private ArrayList<Mascota> cli;
    private String Archivo;
    public daoCliente(String Archivo) {
        cli = new ArrayList<Mascota>();
        this.Archivo = Archivo;
        cargar();
    }

    public void adicionar(Mascota a) {
        cli.add(a);
    }

    public Mascota obtener(int i) {
        return cli.get(i);
    }

    public void eliminar(Mascota a) {
        cli.remove(a);
    }
    
    public int tamaño() {
        return cli.size();
    }

    public Mascota buscar(int ru) {
        for (int i = 0; i < tamaño(); i++) {
            if (ru == cli.get(i).getRuc()) {
                return cli.get(i);
            }
        }
        return null;
    }

    public int getCorrelativo() {
        if (tamaño() == 0) {
            return 1;
        } else {
            return tamaño() + 1;
        }
    }

    public void grabar() {
        try {
            PrintWriter pw;
            String linea;
            pw = new PrintWriter(new FileWriter(Archivo));
            for (int i = 0; i < tamaño(); i++) {
                linea = obtener(i).getRuc() + ";"
                        + obtener(i).getRazon() + ";"
                        + obtener(i).getTelefono() + ";"
                        + obtener(i).getDireccion()+ ";"
                        + obtener(i).getCondicion() + ";";             
                pw.println(linea);
            }
            pw.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void cargar() {
        try {
            BufferedReader br;
            String linea;
            String[] array;
            br = new BufferedReader(new FileReader(Archivo));
            while ((linea = br.readLine()) != null) {
                array = linea.split(";");
                Mascota a = new Mascota(Integer.parseInt(array[0].trim()), 
                        array[1].trim(),
                        Integer.parseInt(array[2].trim()),
                        array[3].trim(),
                        array[4].trim(),
                        array[5].trim()
                );
                adicionar(a);
            }
            br.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

}

