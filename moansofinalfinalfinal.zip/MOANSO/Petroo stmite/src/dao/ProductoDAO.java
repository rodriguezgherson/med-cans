package dao;

import java.util.*;
import java.sql.*;
import datos.Producto;
import Conexiones.Conexion;

public class ProductoDAO {
    
    public ArrayList<Producto> ListarProducto() {
        Connection con = null;
        CallableStatement cstm = null;

        ArrayList<Producto> lista = new ArrayList<Producto>();
        try {
            con = Conexion.getConexion();
            cstm = con.prepareCall("{Call ListaProducto2()}");
            //cstm.setString("country", country.getCountry());
            ResultSet rs = cstm.executeQuery();

            Producto pro;
            while (rs.next()) {
                pro = new Producto(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getFloat(5),rs.getString(6));
                lista.add(pro);
            }
        } catch (Exception e) {
            System.out.print(e);
        }
        return lista;
    }
    public ArrayList<Producto> InsertarProducto(String NombreProducto,int IDMarca,
                                                int Cantidad, float Precio, String UnidadMedida) {
        Connection con = null;
        CallableStatement cstm = null;

        ArrayList<Producto> lista = new ArrayList<Producto>();
        try {
            con = Conexion.getConexion();
            String insertar = "{Call InsertProducto(?,?,?,?,?)}";
            cstm = con.prepareCall(insertar);
            cstm.setString("NOMBRE_PRODUCTO", NombreProducto);
            cstm.setInt("ID_MARCA", IDMarca);
            cstm.setInt("CANTIDAD_PRODUCTO", Cantidad);
            cstm.setFloat("PRECIO_PRODUCTO", Precio);
            cstm.setString("UNIDAD_MEDIDA_PRODUCTO", UnidadMedida);
            //cstm.setString("country", country.getCountry());
            ResultSet rs = cstm.executeQuery();

            Producto pro;
            while (rs.next()) {
                pro = new Producto(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getFloat(5),rs.getString(6));
                lista.add(pro);
            }
        } catch (Exception e) {
            System.out.print(e);
        }
        return lista;
    }
    
    
    
    
    
    
    
    
    
    

}
