package dao;

import java.util.*;
import java.sql.*;
import datos.Mascota;
import Conexiones.Conexion;

public class MascotaDAO {
    public ArrayList<Mascota> ListarMascota() {
        Connection con = null;
        CallableStatement cstm = null;

        ArrayList<Mascota> lista = new ArrayList<Mascota>();
        try {
            con = Conexion.getConexion();
            cstm = con.prepareCall("{Call ListaMascota()}");
            //cstm.setString("country", country.getCountry());
            ResultSet rs = cstm.executeQuery();

            Mascota mas;
            while (rs.next()) {
                pro = new Mascota(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getFloat(5),rs.getString(6));
                lista.add(mas);
            }
        } catch (Exception e) {
            System.out.print(e);
        }
        return lista;
    }
    public ArrayList<Mascota> ConsultarMasc(String NombreMascota) {
        ArrayList<Mascota> lista = new ArrayList<>();
        try {
            PreparedStatement psta = Conexion.getConexion().
               prepareStatement("SELECT * FROM PRODUCTO WHERE NOMBRE_MASCOTA=?");
            psta.setString(1, NombreMascota);
            ResultSet rs = psta.executeQuery();
            
            while(rs.next()){
                Mascota masc;
                masc = new Mascota(rs.getInt(1),
                        rs.getString(2), rs.getString(3),rs.getString(4),
                        rs.getFloat(5), rs.getString(6),rs.getString(7));
                lista.add(masc);
            }
        } catch (Exception e){}
            return lista;
    }
    public ArrayList<Mascota> InsertarMasc(String NombreMascota,String Sexo,String Raza,Float Peso,String FechaNacimiento,String ColorPelaje) {
        try {
            PreparedStatement psta = Conexion.getConexion().
               prepareStatement("INSERT INTO MASCOTA VALUES (?,?,?,?,?,?)");
            psta.setString(1, NombreMascota);
            psta.setString(2, Sexo);
            psta.setString(3, Raza);
            psta.setFloat(4, Peso);
            psta.setString(5, FechaNacimiento);
            psta.setString(6, ColorPelaje);
            
            psta.executeQuery();
            }catch(Exception e){}
        return null;
    }    
    
    public ArrayList<Mascota> ModificarMasc(Float Peso, int IDMascota,String NombreMascota) {
        try {
            PreparedStatement psta = Conexion.getConexion().
            prepareStatement("UPDATE MASCOTA SET PESO=? WHERE ID_MASCOTA=? OR NOMBRE_MASCOTA=? ");
            psta.setFloat(1, Peso);
            psta.setInt(2, IDMascota);
            psta.setString(3, NombreMascota);
            
            psta.executeQuery();
            }catch(Exception e){}
        return null;
    }  
    public ArrayList<Mascota> EliminarMasc(Float Peso, int IDMascota,String NombreMascota) {
        try {
            PreparedStatement psta = Conexion.getConexion().
            prepareStatement("DELETE MASCOTA WHERE ID_MASCOTA=? OR NOMBRE_MASCOTA=? ");
            psta.setInt(1, IDMascota);
            psta.setString(2, NombreMascota);
            
            psta.executeQuery();
            }catch(Exception e){}
        return null;
    }  
    
    
    
    
    
}

