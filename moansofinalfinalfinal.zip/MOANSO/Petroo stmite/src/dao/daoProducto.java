/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.io.*;
import java.util.ArrayList;
import datos.Producto;

/**
 *
 * @author Jean
 */
public class daoProducto {

    /**
     * @param args the command line arguments
     */
    private ArrayList<Producto> pro;
    private String Archivo;

    public daoProducto(String Archivo) {
        pro = new ArrayList<Producto>();
        this.Archivo = Archivo;
        cargar();
    }

    public void adicionar(Producto a) {
        pro.add(a);
    }

    public Producto obtener(int i) {
        return pro.get(i);
    }

    public void eliminar(Producto a) {
        pro.remove(a);
    }

    public int tamaño() {
        return pro.size();
    }

    public Producto buscar(int cod) {
        for (int i = 0; i < tamaño(); i++) {
            if (cod == pro.get(i).getCodigo()) {
                return pro.get(i);
            }
        }
        return null;
    }

    public int getCorrelativo() {
        if (tamaño() == 0) {
            return 1;
        } else {
            return tamaño() + 1;
        }
    }

    public void grabar() {
        try {
            PrintWriter pw;
            String linea;
            pw = new PrintWriter(new FileWriter(Archivo));
            for (int i = 0; i < tamaño(); i++) {
                linea = obtener(i).getCodigo() + ";"
                        + obtener(i).getDescripcion() + ";"
                        + obtener(i).getPrecio() + ";"
                        + pro.get(i).getStock();
                pw.println(linea);
            }
            pw.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void cargar() {
        try {
            BufferedReader br;
            String linea;
            String[] array;
            br = new BufferedReader(new FileReader(Archivo));
            while ((linea = br.readLine()) != null) {
                array = linea.split(";");
                Producto a = new Producto(Integer.parseInt(array[0].trim()),
                        array[1].trim(), Double.parseDouble(array[2].trim()),
                        Integer.parseInt(array[3].trim())
                );
                adicionar(a);
            }
            br.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

}
