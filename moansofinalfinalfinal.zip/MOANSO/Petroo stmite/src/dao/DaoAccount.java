/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import java.io.*;
import java.util.ArrayList;
import datos.User;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author misae
 */
public class DaoAccount {
    private ArrayList<User> pro;
    private String Archivo;

    public DaoAccount(String Archivo) {
        pro = new ArrayList<User>();
        this.Archivo = Archivo;
        cargar();
    }

    public void adicionar( User a) {
        pro.add(a);
    }

    public User obtener(int i) {
        return pro.get(i);
    }
    public void eliminar(User a) {
        pro.remove(a);
    }
      


    public int tamaño() {
        return pro.size();
    }


    public int getCorrelativo() {
        if (tamaño() == 0) {
            return 1;
        } else {
            return tamaño() + 1;
        }
    }

    public void grabar() {
        try {
            PrintWriter pw;
            String linea;
            pw = new PrintWriter(new FileWriter(Archivo));
            for (int i = 0; i < tamaño(); i++) {
                linea = obtener(i).getUser() + ";"
                        + obtener(i).getPass() +";"+ obtener(i).getTipo();
                pw.println(linea);
            }
            pw.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void listar(JTable tabla, DefaultTableModel dtm){
    dtm.setRowCount(0);
    for(User obj:pro){ //"obj" almacena elementos tipo "matricula" de la list "mat"
        Object vec[] = new Object[3];
        vec[0] = obj.getUser();
        vec[1] = obj.getPass();
        vec[2] = obj.getTipo();
        
        dtm.addRow(vec);
    }
    tabla.setModel(dtm);
    }
    public void cargar() {
        try {
            BufferedReader br;
            String linea;
            String[] array;
            br = new BufferedReader(new FileReader(Archivo));
            while ((linea = br.readLine()) != null) {
                array = linea.split(";");
                User a = new User(array[0].trim(),
                        array[1].trim(), array[2].trim()
                );
                adicionar(a);
            }
            br.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
     public User buscar(String user){
     for(int i=0;i<tamaño();i++){
         if(user.equals(pro.get(i).getUser()))
             return pro.get(i);
     }
     return null;
  }
}
